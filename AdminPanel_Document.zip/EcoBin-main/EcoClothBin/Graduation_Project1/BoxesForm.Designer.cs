﻿namespace Graduation_Project1
{
    partial class BoxesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BoxesForm));
            DevExpress.XtraCharts.SimpleDiagram3D simpleDiagram3D1 = new DevExpress.XtraCharts.SimpleDiagram3D();
            DevExpress.XtraCharts.Series series1 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.Pie3DSeriesView pie3DSeriesView1 = new DevExpress.XtraCharts.Pie3DSeriesView();
            DevExpress.XtraCharts.XYDiagram xyDiagram1 = new DevExpress.XtraCharts.XYDiagram();
            DevExpress.XtraCharts.Series series2 = new DevExpress.XtraCharts.Series();
            this.ribbonPage1 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.barBox1 = new DevExpress.XtraBars.BarCheckItem();
            this.barBox2 = new DevExpress.XtraBars.BarCheckItem();
            this.barBox3 = new DevExpress.XtraBars.BarCheckItem();
            this.barBox4 = new DevExpress.XtraBars.BarCheckItem();
            this.barBox5 = new DevExpress.XtraBars.BarCheckItem();
            this.barBox6 = new DevExpress.XtraBars.BarCheckItem();
            this.barBox7 = new DevExpress.XtraBars.BarCheckItem();
            this.barBox8 = new DevExpress.XtraBars.BarCheckItem();
            this.barBox9 = new DevExpress.XtraBars.BarCheckItem();
            this.barBox10 = new DevExpress.XtraBars.BarCheckItem();
            this.ribbonPageGroup2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem2 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem3 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem4 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem5 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem6 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem7 = new DevExpress.XtraBars.BarButtonItem();
            this.repositoryItemComboBox1 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.repositoryItemComboBox2 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.chartControl2 = new DevExpress.XtraCharts.ChartControl();
            this.chartControl1 = new DevExpress.XtraCharts.ChartControl();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.barButtonItem8 = new DevExpress.XtraBars.BarButtonItem();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(simpleDiagram3D1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(pie3DSeriesView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(xyDiagram1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // ribbonPage1
            // 
            this.ribbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup1,
            this.ribbonPageGroup2});
            this.ribbonPage1.ImageOptions.SvgImage = global::Graduation_Project1.Properties.Resources.boxes;
            this.ribbonPage1.ImageOptions.SvgImageSize = new System.Drawing.Size(60, 60);
            this.ribbonPage1.Name = "ribbonPage1";
            this.ribbonPage1.Text = "BOXES";
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.ItemLinks.Add(this.barBox1);
            this.ribbonPageGroup1.ItemLinks.Add(this.barBox2);
            this.ribbonPageGroup1.ItemLinks.Add(this.barBox3);
            this.ribbonPageGroup1.ItemLinks.Add(this.barBox4);
            this.ribbonPageGroup1.ItemLinks.Add(this.barBox5);
            this.ribbonPageGroup1.ItemLinks.Add(this.barBox6);
            this.ribbonPageGroup1.ItemLinks.Add(this.barBox7);
            this.ribbonPageGroup1.ItemLinks.Add(this.barBox8);
            this.ribbonPageGroup1.ItemLinks.Add(this.barBox9);
            this.ribbonPageGroup1.ItemLinks.Add(this.barBox10);
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            this.ribbonPageGroup1.Text = "BOXES";
            // 
            // barBox1
            // 
            this.barBox1.Caption = "box1";
            this.barBox1.Id = 1;
            this.barBox1.ImageOptions.Image = global::Graduation_Project1.Properties.Resources.cupboard_6283642;
            this.barBox1.Name = "barBox1";
            this.barBox1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.barBox1.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barBox1_CheckedChanged);
            // 
            // barBox2
            // 
            this.barBox2.Caption = "box2";
            this.barBox2.Id = 2;
            this.barBox2.ImageOptions.Image = global::Graduation_Project1.Properties.Resources.cupboard_6283642;
            this.barBox2.Name = "barBox2";
            this.barBox2.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.barBox2.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barBox2_CheckedChanged);
            // 
            // barBox3
            // 
            this.barBox3.Caption = "BOX 3";
            this.barBox3.Id = 3;
            this.barBox3.ImageOptions.Image = global::Graduation_Project1.Properties.Resources.cupboard_6283642;
            this.barBox3.Name = "barBox3";
            this.barBox3.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.barBox3.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barBox3_CheckedChanged);
            // 
            // barBox4
            // 
            this.barBox4.Caption = "BOX 4";
            this.barBox4.Id = 4;
            this.barBox4.ImageOptions.Image = global::Graduation_Project1.Properties.Resources.cupboard_6283642;
            this.barBox4.Name = "barBox4";
            this.barBox4.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.barBox4.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barBox4_CheckedChanged);
            // 
            // barBox5
            // 
            this.barBox5.Caption = "BOX 5";
            this.barBox5.Id = 5;
            this.barBox5.ImageOptions.Image = global::Graduation_Project1.Properties.Resources.cupboard_6283642;
            this.barBox5.Name = "barBox5";
            this.barBox5.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.barBox5.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barBox5_CheckedChanged);
            // 
            // barBox6
            // 
            this.barBox6.Caption = "BOX 6";
            this.barBox6.Id = 6;
            this.barBox6.ImageOptions.Image = global::Graduation_Project1.Properties.Resources.cupboard_6283642;
            this.barBox6.Name = "barBox6";
            this.barBox6.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.barBox6.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.barBox6.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barBox6_CheckedChanged);
            // 
            // barBox7
            // 
            this.barBox7.Caption = "BOX 7";
            this.barBox7.Id = 19;
            this.barBox7.ImageOptions.Image = global::Graduation_Project1.Properties.Resources.cupboard_6283642;
            this.barBox7.Name = "barBox7";
            this.barBox7.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.barBox7.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barBox7_CheckedChanged);
            // 
            // barBox8
            // 
            this.barBox8.Caption = "BOX 8";
            this.barBox8.Id = 20;
            this.barBox8.ImageOptions.Image = global::Graduation_Project1.Properties.Resources.cupboard_6283642;
            this.barBox8.Name = "barBox8";
            this.barBox8.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.barBox8.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barBox8_CheckedChanged);
            // 
            // barBox9
            // 
            this.barBox9.Caption = "BOX 9";
            this.barBox9.Id = 21;
            this.barBox9.ImageOptions.Image = global::Graduation_Project1.Properties.Resources.cupboard_6283642;
            this.barBox9.Name = "barBox9";
            this.barBox9.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.barBox9.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barBox9_CheckedChanged);
            // 
            // barBox10
            // 
            this.barBox10.Caption = "BOX 10";
            this.barBox10.Id = 23;
            this.barBox10.ImageOptions.Image = global::Graduation_Project1.Properties.Resources.cupboard_6283642;
            this.barBox10.Name = "barBox10";
            this.barBox10.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.barBox10.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barBox10_CheckedChanged);
            // 
            // ribbonPageGroup2
            // 
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem1);
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem2);
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem3);
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem4);
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem5);
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem6);
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem7);
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem8);
            this.ribbonPageGroup2.Name = "ribbonPageGroup2";
            this.ribbonPageGroup2.Text = "OPERATIONS";
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "GRAPHICS";
            this.barButtonItem1.Id = 13;
            this.barButtonItem1.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem1.ImageOptions.SvgImage")));
            this.barButtonItem1.Name = "barButtonItem1";
            this.barButtonItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.barButtonItem1.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem1_ItemClick);
            // 
            // barButtonItem2
            // 
            this.barButtonItem2.Caption = "LIST";
            this.barButtonItem2.Id = 14;
            this.barButtonItem2.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem2.ImageOptions.SvgImage")));
            this.barButtonItem2.Name = "barButtonItem2";
            this.barButtonItem2.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.barButtonItem2.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem2_ItemClick);
            // 
            // barButtonItem3
            // 
            this.barButtonItem3.Caption = "EXPORT";
            this.barButtonItem3.Id = 15;
            this.barButtonItem3.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem3.ImageOptions.SvgImage")));
            this.barButtonItem3.Name = "barButtonItem3";
            this.barButtonItem3.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.barButtonItem3.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem3_ItemClick);
            // 
            // barButtonItem4
            // 
            this.barButtonItem4.Caption = "DELETE BOX";
            this.barButtonItem4.Id = 16;
            this.barButtonItem4.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem4.ImageOptions.SvgImage")));
            this.barButtonItem4.Name = "barButtonItem4";
            this.barButtonItem4.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.barButtonItem4.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem4_ItemClick);
            // 
            // barButtonItem5
            // 
            this.barButtonItem5.Caption = "CLOTHES PAGE";
            this.barButtonItem5.Id = 17;
            this.barButtonItem5.ImageOptions.SvgImage = global::Graduation_Project1.Properties.Resources.kıyafetler;
            this.barButtonItem5.Name = "barButtonItem5";
            this.barButtonItem5.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.barButtonItem5.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem5_ItemClick);
            // 
            // barButtonItem6
            // 
            this.barButtonItem6.Caption = "HOME PAGE";
            this.barButtonItem6.Id = 18;
            this.barButtonItem6.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem6.ImageOptions.SvgImage")));
            this.barButtonItem6.Name = "barButtonItem6";
            this.barButtonItem6.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.barButtonItem6.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem6_ItemClick);
            // 
            // barButtonItem7
            // 
            this.barButtonItem7.Caption = "SHOW ON MAP";
            this.barButtonItem7.Id = 24;
            this.barButtonItem7.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("barButtonItem7.ImageOptions.Image")));
            this.barButtonItem7.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("barButtonItem7.ImageOptions.LargeImage")));
            this.barButtonItem7.Name = "barButtonItem7";
            this.barButtonItem7.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.barButtonItem7.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem7_ItemClick);
            // 
            // repositoryItemComboBox1
            // 
            this.repositoryItemComboBox1.AutoHeight = false;
            this.repositoryItemComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox1.Name = "repositoryItemComboBox1";
            // 
            // repositoryItemComboBox2
            // 
            this.repositoryItemComboBox2.AutoHeight = false;
            this.repositoryItemComboBox2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox2.Name = "repositoryItemComboBox2";
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.ExpandCollapseItem.Id = 0;
            this.ribbonControl1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl1.ExpandCollapseItem,
            this.ribbonControl1.SearchEditItem,
            this.barBox1,
            this.barBox2,
            this.barBox3,
            this.barBox4,
            this.barBox5,
            this.barBox6,
            this.barButtonItem1,
            this.barButtonItem2,
            this.barButtonItem3,
            this.barButtonItem4,
            this.barButtonItem5,
            this.barButtonItem6,
            this.barBox7,
            this.barBox8,
            this.barBox9,
            this.barBox10,
            this.barButtonItem7,
            this.barButtonItem8});
            this.ribbonControl1.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl1.MaxItemId = 26;
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage1});
            this.ribbonControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox1,
            this.repositoryItemComboBox2});
            this.ribbonControl1.Size = new System.Drawing.Size(1264, 197);
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.chartControl2);
            this.groupControl1.Controls.Add(this.chartControl1);
            this.groupControl1.Location = new System.Drawing.Point(675, 203);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(577, 606);
            this.groupControl1.TabIndex = 1;
            this.groupControl1.Text = "Charts";
            // 
            // chartControl2
            // 
            simpleDiagram3D1.RotationMatrixSerializable = "0.50757703975855;-0.594641368292351;-0.623511982102499;0;-0.348928038065821;-0.80" +
    "3529789805646;0.482274922784169;0;-0.787791071897577;-0.0272308650310126;-0.6153" +
    "40318058378;0;0;0;0;1";
            this.chartControl2.Diagram = simpleDiagram3D1;
            this.chartControl2.Legend.Name = "Default Legend";
            this.chartControl2.Location = new System.Drawing.Point(2, 320);
            this.chartControl2.Name = "chartControl2";
            series1.Name = "Series 1";
            series1.View = pie3DSeriesView1;
            this.chartControl2.SeriesSerializable = new DevExpress.XtraCharts.Series[] {
        series1};
            this.chartControl2.Size = new System.Drawing.Size(581, 286);
            this.chartControl2.TabIndex = 1;
            // 
            // chartControl1
            // 
            this.chartControl1.BorderOptions.Visibility = DevExpress.Utils.DefaultBoolean.True;
            xyDiagram1.AxisX.VisibleInPanesSerializable = "-1";
            xyDiagram1.AxisY.VisibleInPanesSerializable = "-1";
            this.chartControl1.Diagram = xyDiagram1;
            this.chartControl1.Legend.Name = "Default Legend";
            this.chartControl1.Location = new System.Drawing.Point(0, 26);
            this.chartControl1.Name = "chartControl1";
            series2.LegendTextPattern = "{A}";
            series2.Name = "Clothes";
            this.chartControl1.SeriesSerializable = new DevExpress.XtraCharts.Series[] {
        series2};
            this.chartControl1.Size = new System.Drawing.Size(583, 283);
            this.chartControl1.TabIndex = 0;
            // 
            // gridControl1
            // 
            this.gridControl1.Location = new System.Drawing.Point(0, 203);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.MenuManager = this.ribbonControl1;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.Size = new System.Drawing.Size(669, 606);
            this.gridControl1.TabIndex = 2;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.Name = "gridView1";
            // 
            // barButtonItem8
            // 
            this.barButtonItem8.Caption = "LOG OUT";
            this.barButtonItem8.Id = 25;
            this.barButtonItem8.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem8.ImageOptions.SvgImage")));
            this.barButtonItem8.Name = "barButtonItem8";
            this.barButtonItem8.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.barButtonItem8.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem8_ItemClick);
            // 
            // BoxesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 821);
            this.Controls.Add(this.gridControl1);
            this.Controls.Add(this.groupControl1);
            this.Controls.Add(this.ribbonControl1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "BoxesForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BoxesForm";
            this.Load += new System.EventHandler(this.BoxesForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(simpleDiagram3D1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(pie3DSeriesView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartControl2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(xyDiagram1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraBars.BarCheckItem barBox1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup2;
        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
        private DevExpress.XtraBars.BarCheckItem barBox2;
        private DevExpress.XtraBars.BarCheckItem barBox3;
        private DevExpress.XtraBars.BarCheckItem barBox4;
        private DevExpress.XtraBars.BarCheckItem barBox5;
        private DevExpress.XtraBars.BarCheckItem barBox6;
        private DevExpress.XtraBars.BarCheckItem barBox7;
        private DevExpress.XtraBars.BarCheckItem barBox8;
        private DevExpress.XtraBars.BarCheckItem barBox9;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox1;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem3;
        private DevExpress.XtraBars.BarButtonItem barButtonItem4;
        private DevExpress.XtraBars.BarButtonItem barButtonItem5;
        private DevExpress.XtraBars.BarButtonItem barButtonItem6;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraCharts.ChartControl chartControl2;
        private DevExpress.XtraCharts.ChartControl chartControl1;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraBars.BarCheckItem barBox10;
        private DevExpress.XtraBars.BarButtonItem barButtonItem7;
        private DevExpress.XtraBars.BarButtonItem barButtonItem8;
    }
}